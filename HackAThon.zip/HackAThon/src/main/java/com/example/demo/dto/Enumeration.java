package com.example.demo.dto;

enum EVENTS{
	INSERTED, DELETED, MOVED, MODIFIED
}
