package com.example.demo.entity;

enum EVENTS{
	INSERTED, DELETED, MOVED, MODIFIED
}
