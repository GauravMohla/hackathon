package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.UserDto;
import com.example.demo.entity.Box;
import com.example.demo.service.UserService;
import com.example.demo.utils.Constants;

/**
 * Created by ashish on 13/5/17.
 */
@RequestMapping("/user")
@RestController
public class UserController {
	@Autowired
	UserService userService;
	
	
	@RequestMapping("/saveBox")
	public String saveBox(@RequestBody Box bi) throws Exception {
		 System.out.println(bi.toString());
		 userService.addBox(bi);
		 return "Saved";
	}
	
	@RequestMapping("/getAtTime/{l}")
	public String getAllBoxesAtTime(@PathVariable long l) throws Exception {
		 System.out.println(userService.getAllBoxesAtTime(l));
		 return "Saved";
	}
	
	@RequestMapping("/boxinbox/{b1}/{b2}")
	public String binb(@PathVariable("b1") String b1, @PathVariable("b2") String b2) throws Exception {
		 userService.addBoxInBox(b1, b2);
		 return null;
	}

	@RequestMapping(Constants.GET_USER_BY_ID)
	public UserDto getUserById(@PathVariable Integer userId) {
		return userService.getUserById(userId);
	}
	
	@RequestMapping(Constants.GET_ALL_USERS)
	public List<UserDto> getAllUsers() {
		return userService.getAllUsers();
	}
	
	@RequestMapping(value= Constants.SAVE_USER, method= RequestMethod.POST)
	public void saveUser(@RequestBody UserDto userDto) {
		userService.saveUser(userDto);
	}
}
