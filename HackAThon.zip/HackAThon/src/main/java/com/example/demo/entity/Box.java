package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Box implements Cloneable{
	@Column
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
    private String boxiID;
	@Column
	private String boxID;
	@Column
    private String locationId;
	@Column
    private boolean hasParent;
	@Column
    private String parentName;
	@Column
    private boolean hasChild;
	@Column
    private String childs;
	@Column
    private EVENTS eventType;
	@Column
    private long starttimeStamp;
	@Column
    private long endtimeStamp;
	public Object clone() throws
    CloneNotSupportedException 
{ 
return super.clone(); 
} 
	public String getBoxiID() {
		return boxiID;
	}
	public void setBoxiID(String boxiID) {
		this.boxiID = boxiID;
	}
	public String getBoxID() {
		return boxID;
	}
	public void setBoxID(String boxID) {
		this.boxID = boxID;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public boolean isHasParent() {
		return hasParent;
	}
	public void setHasParent(boolean hasParent) {
		this.hasParent = hasParent;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public boolean isHasChild() {
		return hasChild;
	}
	public void setHasChild(boolean hasChild) {
		this.hasChild = hasChild;
	}
	public String getChilds() {
		return childs;
	}
	public void setChilds(String childs) {
		this.childs = childs;
	}
	public EVENTS getEventType() {
		return eventType;
	}
	public void setEventType(EVENTS eventType) {
		this.eventType = eventType;
	}
	public long getStarttimeStamp() {
		return starttimeStamp;
	}
	public void setStarttimeStamp(long starttimeStamp) {
		this.starttimeStamp = starttimeStamp;
	}
	public long getEndtimeStamp() {
		return endtimeStamp;
	}
	public void setEndtimeStamp(long endtimeStamp) {
		this.endtimeStamp = endtimeStamp;
	}
	@Override
	public String toString() {
		return "Box [boxiID=" + boxiID + ", boxID=" + boxID + ", locationId=" + locationId + ", hasParent=" + hasParent
				+ ", parentName=" + parentName + ", hasChild=" + hasChild + ", childs=" + childs + ", eventType="
				+ eventType + ", starttimeStamp=" + starttimeStamp + ", endtimeStamp=" + endtimeStamp + "]";
	}
	
}
