package com.example.demo.service;

import java.util.List;

import com.example.demo.dto.UserDto;
import com.example.demo.entity.Box;


public interface UserService {
    UserDto getUserById(Integer userId);
    List<String> getAllBoxInstances();
    void saveUser(UserDto userDto);
    List<UserDto> getAllUsers();
    void addBox(Box b) throws Exception;
    List<Box> getAllBoxesAtTime(long l);
    void addBoxInBox(String bid, String bid1) throws Exception;
}
