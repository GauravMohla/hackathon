package com.example.demo.dto;

public class BoxDTO {
	private String boxID;
    private String locationId;
    private boolean hasParent;
    private String parentName;
    private boolean hasChild;
    public String getBoxID() {
		return boxID;
	}
	public void setBoxID(String boxID) {
		this.boxID = boxID;
	}
	public String getLocationId() {
		return locationId;
	}
	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}
	public boolean isHasParent() {
		return hasParent;
	}
	public void setHasParent(boolean hasParent) {
		this.hasParent = hasParent;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public boolean isHasChild() {
		return hasChild;
	}
	public void setHasChild(boolean hasChild) {
		this.hasChild = hasChild;
	}
	public String getChilds() {
		return childs;
	}
	public void setChilds(String childs) {
		this.childs = childs;
	}
	public EVENTS getEventType() {
		return eventType;
	}
	public void setEventType(EVENTS eventType) {
		this.eventType = eventType;
	}
	public long getStarttimeStamp() {
		return starttimeStamp;
	}
	public void setStarttimeStamp(long starttimeStamp) {
		this.starttimeStamp = starttimeStamp;
	}
	public long getEndtimeStamp() {
		return endtimeStamp;
	}
	public void setEndtimeStamp(long endtimeStamp) {
		this.endtimeStamp = endtimeStamp;
	}
	private long starttimeStamp;
	private long endtimeStamp;
	private String childs;
    private EVENTS eventType;
}
