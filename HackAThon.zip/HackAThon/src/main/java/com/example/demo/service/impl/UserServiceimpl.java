package com.example.demo.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.converter.UserConverter;
import com.example.demo.dto.UserDto;
import com.example.demo.entity.Box;
import com.example.demo.repository.BoxRepo;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;

@Service
public class UserServiceimpl implements UserService {
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	BoxRepo br;

	/*
	 * @Override public UserDto getUserById(Integer userId) { return
	 * UserConverter.entityToDto(userRepository.getOne(userId)); }
	 * 
	 * @Override public void saveUser(UserDto userDto) {
	 * userRepository.save(UserConverter.dtoToEntity(userDto)); }
	 * 
	 * @Override public List<UserDto> getAllUsers() { return
	 * userRepository.findAll().stream().map(UserConverter::entityToDto).collect(
	 * Collectors.toList()); }
	 */

	@Override
	public List<String> getAllBoxInstances() {
		// TODO Auto-generated method stub
		
		
		return null;
	}
	@Override
	public void addBox(Box bi) throws Exception{
		String bid = bi.getBoxID();
		br.save(UserConverter.saveBoxInDB(bi));
		System.out.println("The box id is "+bid);
		List<Box> bl = br.findAll(Arrays.asList(new String(bid)));
		System.out.println(bl);
		br.save(UserConverter.saveBoxInDB(bi));
		System.out.println(br.findAll());
	}
	
	@Override
	public void addBoxInBox(String bid, String bid1) throws Exception{
		// add bid in bid1
		List<Box> bc = br.findAll();
		int r1=0; int r2=0;
		for(int i=0;i<bc.size();i++) {
			if(bc.get(i).getEndtimeStamp()==0 && bc.get(i).getBoxID().equals(bid)) {
				r1=i;
			}
			if(bc.get(i).getEndtimeStamp()==0 && bc.get(i).getBoxID().equals(bid1)) {
				r2=i;
			}
		}
		Box rone = bc.remove(r1);
		Box rtwo = bc.remove(r2);
		Box bb = (Box) rtwo.clone();
		long cts = System.currentTimeMillis();
		bb.setHasChild(true);
		rtwo.setEndtimeStamp(cts);
		bb.setStarttimeStamp(cts);
		String f = rtwo.getChilds();
		if (f== null) {
			bb.setChilds(rone.getBoxID());
		} else {
			bb.setChilds(f+","+rone.getBoxID());
		}
		bc.add(rtwo);
		bc.add(bb);
		br.deleteAll();
		for (Box v: bc) {
			br.save(UserConverter.saveBoxInDB(v));
			System.out.println(v);
		}
		System.out.println("The list now is ");
		System.out.println(bc);
	} 
	
	@Override
	public List<Box> getAllBoxesAtTime(long l){
		List<Box> bc = br.findAll();
		List<Box> retL = new ArrayList<>();
		if (l==0l) {
			for(Box c: bc) {
				if(c.getEndtimeStamp()==0) {
					System.out.println(String.format("The box %s is in location %s", c.getBoxID(), c.getLocationId()));
					retL.add(c);
				}
			}
		} else {
			for(Box c: bc) {
				if((c.getEndtimeStamp()==0 && c.getStarttimeStamp()<l) || (c.getEndtimeStamp()>=l && c.getStarttimeStamp()<l)) {
					System.out.println(String.format("The box %s is in location %s", c.getBoxID(), c.getLocationId()));
					retL.add(c);
				}
			}
		}
		return retL;
	}

	@Override
	public UserDto getUserById(Integer userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void saveUser(UserDto userDto) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<UserDto> getAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}
}
